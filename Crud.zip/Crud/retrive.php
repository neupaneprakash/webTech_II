<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Student Record</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container,
        .data-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 10px;
        }

        .form-container {
            width: 300px;
        }

        .data-container {
            flex-grow: 1;
        }

        label {
            font-weight: bold;
        }

        input {
            width: 100%;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <form method="post" action="update.php">
            <h2 class="mb-4">Update Student Record</h2>
            <label for ="id">ID:</label>
            <input type="text" name ="id" class="form-control" required>
            <label for="firstname">First Name:</label>
            <input type="text" name="firstname" class="form-control" required>
            <label for="lastname">Last Name:</label>
            <input type="text" name="lastname" class="form-control" required>
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control" required>
            <input type="submit" class="btn btn-primary" value="Modify/Update Record">
        </form>
    </div>

    <div class="data-container">
        <h2>Data Table</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Option</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "Webtech";
                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                    $sql = "SELECT id, firstname, lastname, email FROM students";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $row["id"] . '</td>';
                            echo '<td>' . $row["firstname"] . '</td>';
                            echo '<td>' . $row["lastname"] . '</td>';
                            echo '<td>' . $row["email"] . '</td>';
                            echo '<td>' . "<a href='delete.php?id=".$row['id']."'>Delete</a>" . '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="5">0 results</td></tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
