<?php
session_start();

// Check for Basic Authentication
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="Authentication required"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Authentication required.';
    exit;
}

$username = $_SERVER['PHP_AUTH_USER'];
$password = $_SERVER['PHP_AUTH_PW'];

// Validate the user credentials against the database
if (!authenticateUser($username, $password)) {
    header('WWW-Authenticate: Basic realm="Authentication required"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Invalid credentials.';
    exit;
}

// Continue with the rest of the code
$timeout = 60; // 60 seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    setcookie('remember_me', '', time() - 3600, '/');
    header('Location: login.php?expired=1');
    exit;
}

$_SESSION['last_activity'] = time();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
    <p>This is your dashboard.</p>
    
    <form action="logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</body>
</html>

<?php
// Define the authenticateUser function here
function authenticateUser($username, $password) {
    $db = new PDO('mysql:host=localhost;dbname=users', 'root', '');

    $query = $db->prepare("SELECT * FROM user_credentials WHERE username = :username AND password = :password");
    $query->bindParam(':username', $username);
    $query->bindParam(':password', $password);
    $query->execute();

    return $query->rowCount() > 0;
}
?>

