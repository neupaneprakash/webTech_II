<?php
session_start();

if (!isset($_SESSION['username'])) {
    if (isset($_COOKIE['remember_me'])) {
        $username = $_COOKIE['remember_me'];
        $_SESSION['username'] = $username;
        $_SESSION['last_activity'] = time();

        // Refresh the cookie expiration time
        setcookie('remember_me', $username, time() + 86400, '/');
    } else {
        header('Location: login.php');
        exit;
    }
}

$timeout = 15; // 15 seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    setcookie('remember_me', '', time() - 3600, '/');
    header('Location: login.php?expired=1');
    exit;
}

$_SESSION['last_activity'] = time();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
    <p>This is your dashboard.</p>
    
    <form action="logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</body>
</html>
