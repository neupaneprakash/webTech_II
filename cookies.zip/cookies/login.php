<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate the user credentials against the database
    if (authenticateUser($username, $password)) {
        $_SESSION['username'] = $username;
        $_SESSION['last_activity'] = time(); // Set the last activity time

        // Set a cookie to remember the user for 1 day (86400 seconds)
        setcookie('remember_me', $username, time() + 86400, '/');

        header('Location: dashboard.php');
        exit;
    } else {
        $error_message = 'Invalid username or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    
    <?php if (isset($error_message)) : ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" value="Login">
    </form>
</body>
</html>

<?php
function authenticateUser($username, $password) {
    $db = new PDO('mysql:host=localhost;dbname=users', 'root', '');

    $query = $db->prepare("SELECT * FROM user_credentials WHERE username = :username AND password = :password");
    $query->bindParam(':username', $username);
    $query->bindParam(':password', $password);
    $query->execute();

    return $query->rowCount() > 0;
}
?>
