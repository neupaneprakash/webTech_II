<?php
$myfile = fopen("bit.txt", "a") or die("Unable to open file!");
$txt = "and some more text are added\n";
fwrite($myfile, $txt);
fclose($myfile);
?>