<!DOCTYPE html>
<html>
<body>

<?php
$myfile = fopen("bit.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("bit.txt"));
fclose($myfile);
?>

</body>
</html>