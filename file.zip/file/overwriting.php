<?php
$myfile = fopen("bit.txt", "w") or die("Unable to open file!");
$txt = " hello\n";
fwrite($myfile, $txt);
echo readfile("bit.txt");
fclose($myfile);
?>