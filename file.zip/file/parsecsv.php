<?php
$filename = 'data.csv';

// Check if the file exists and is readable
if (($handle = fopen($filename, 'r')) !== false) {
    echo "<table border='1'>";
    // Read each line from the file
    while (($data = fgetcsv($handle, 1000, ',')) !== false) {
        echo "<tr>";
        // Output each column value
        foreach ($data as $value) {
            echo "<td>$value</td>";
        }
        echo "</tr>";
    }
    echo "</table>";

    // Close the file handle
    fclose($handle);
} else {
    echo "Cannot open the file.";
}
?>
