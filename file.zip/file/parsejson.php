<?php
$filename = 'data.json';

// Check if the file exists and is readable
if (file_exists($filename) && is_readable($filename)) {
    // Read file contents
    $jsonContent = file_get_contents($filename);

    // Decode JSON data to PHP array
    $data = json_decode($jsonContent, true);

    if ($data !== null) {
        echo "<table border='1'>";
        foreach ($data['employees'] as $employee) {
            echo "<tr>";
            echo "<td>{$employee['name']}</td>";
            echo "<td>{$employee['email']}</td>";
            echo "<td>{$employee['phone']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Invalid JSON format.";
    }
} else {
    echo "Cannot open the file.";
}
?>
