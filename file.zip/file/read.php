<!DOCTYPE html>
<html>
<body>

<?php
echo readfile("bit.txt");
?>

</body>
</html>