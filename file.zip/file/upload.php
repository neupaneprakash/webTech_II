<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Image";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $personName = $_POST["personName"];
    $targetDirectory = "C:/xampp/htdocs/img/"; // Use forward slashes or escape backslashes
    $targetFile = $targetDirectory . basename($_FILES["imageFile"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if file is a JPG
    if ($imageFileType != "jpg") {
        echo "Sorry, only JPG files are allowed.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size (adjust this value as needed)
    if ($_FILES["imageFile"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Upload file if all checks pass
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["imageFile"]["tmp_name"], $targetFile)) {
            // File uploaded successfully, insert data into database (adjust table name and columns accordingly)
            $fileName = basename($_FILES["imageFile"]["name"]);

            $sql = "INSERT INTO person_details (person_name, image_file) VALUES ('$personName', '$fileName')";

            if ($conn->query($sql) === TRUE) {
                echo "Person's details and image have been uploaded and inserted into the database.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

$conn->close();
?>
