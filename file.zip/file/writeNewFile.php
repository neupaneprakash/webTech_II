<?php
$myfile = fopen("newBit.txt", "w") or die("Unable to open file!");
$txt = "Hello! Welcome to the last class of this Semester.\n";
fwrite($myfile, $txt);
$txt = " Hope we will meet in upcoming Semester...!\n";
fwrite($myfile, $txt);
fclose($myfile);
?>